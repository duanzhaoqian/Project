﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Data
{
    public class SubData
    {
        public string Type { get; set; }
        public string[] SubStrings { get; set; }
    }
}
